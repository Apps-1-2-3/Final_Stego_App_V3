import cv2
import tempfile
import numpy as np

from PIL import Image

from .encryption import encrypt, decrypt
from .embedding import embed
from .extraction import extract


FRAME_INDEX = 0


def embed_message_in_video(video_path, message, password):

    message = message[:80]

    encrypted = encrypt(message, password)

    cap = cv2.VideoCapture(video_path)

    if not cap.isOpened():
        raise Exception("Cannot open video")

    fps = cap.get(cv2.CAP_PROP_FPS)

    width = int(cap.get(cv2.CAP_PROP_FRAME_WIDTH))
    height = int(cap.get(cv2.CAP_PROP_FRAME_HEIGHT))

    fourcc = cv2.VideoWriter_fourcc(*'FFV1')

    temp_output = tempfile.NamedTemporaryFile(
        delete=False,
        suffix='.avi'
    )

    temp_output = tempfile.NamedTemporaryFile(
        delete=False,
        suffix=".mp4"
    )

    out = cv2.VideoWriter(
        temp_output.name,
        fourcc,
        fps,
        (width, height)
    )

    frame_count = 0

    while True:

        ret, frame = cap.read()

        if not ret:
            break

        if frame_count == FRAME_INDEX:

            rgb = cv2.cvtColor(
                frame,
                cv2.COLOR_BGR2RGB
            )

            pil_img = Image.fromarray(rgb)

            stego_img = embed(
                pil_img,
                encrypted,
                password
            )

            frame = cv2.cvtColor(
                np.array(stego_img),
                cv2.COLOR_RGB2BGR
            )

        out.write(frame)

        frame_count += 1

    cap.release()
    out.release()

    return temp_output.name


def extract_message_from_video(video_path, password):

    cap = cv2.VideoCapture(video_path)

    if not cap.isOpened():
        raise Exception("Cannot open video")

    frame_count = 0

    while True:

        ret, frame = cap.read()

        if not ret:
            break

        if frame_count == FRAME_INDEX:

            rgb = cv2.cvtColor(
                frame,
                cv2.COLOR_BGR2RGB
            )

            pil_img = Image.fromarray(rgb)

            try:
                blob = extract(
                    pil_img,
                    password
                )

                message = decrypt(
                    blob,
                    password
                )

                cap.release()
                return message

            except Exception as e:

                cap.release()

                raise Exception(
                    f"Decode failed: {str(e)}"
                )

        frame_count += 1

    cap.release()

    raise Exception("No hidden message found")